from django.urls import path
from . import views
urlpatterns:list = [
    path('',views.home,name='home'),
    path('upload_file/',views.upload_file,name='upload_file'),
    path('search_page/',views.search_page,name='search_page'),
    path('search_file/',views.search_file,name='search_file')
]