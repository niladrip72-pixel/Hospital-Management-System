from django.shortcuts import render
from django.conf import settings
from django.http import HttpRequest,HttpResponse,JsonResponse
import os
import pandas as pd
from .pydantic_models import LibraryData

def home(request:HttpRequest)->HttpResponse:
   # Get the previous visit count from the session.
    # If count does not exists , take 0
    count = request.session.get('count',0)
    # check whether is the first visit or not.
    if count == 0:
        is_first_visit:bool = True
        message:str = 'Welcome to The Library for the First Time.'
    else:
        is_first_visit:bool = False
        message = 'Thank You for Visiting Our Library again. We hope, we can give you the best Service.'
    # Increase the visit count
    count += 1

    # Store the updated count in the session
    request.session['count'] = count
    return render(request,'index.html',{'message':message,'count':count,'is_first_visit':is_first_visit})
def upload_file(request:HttpRequest):
    context: dict = {}
    if request.method == 'POST' and request.FILES.get('file'):
        # Getting data from form
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone_number')
        issue_date = request.POST.get('issue_date')
        return_date = request.POST.get('return_date')
        uploaded_file = request.FILES['file']
        # ---------------- PYDANTIC VALIDATION ----------------
        try:
            validated_data = LibraryData(
                name=name,
                email=email,
                phone_number=phone_number,
                issue_date=issue_date,
                return_date=return_date
            )
        except Exception as e:
            context['error'] = str(e)
            # home.html is rendered inside upload_file()
            return render(request, 'home.html', context)
        # ---------------- FILE PATH ----------------
        file_path = os.path.join(settings.MEDIA_ROOT,uploaded_file.name)
        try:
            # ---------------- SAVE CSV FILE ----------------
            with open(file_path, 'wb+') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)
            # ---------------- READ CSV ----------------
            df: pd.DataFrame = pd.read_csv(file_path)
            # --------------- STORE DATA IN SESSION ----------------
            request.session['csv_file'] = uploaded_file.name
            request.session['name'] = validated_data.name
            request.session['email'] = validated_data.email
            request.session['phone_number'] = validated_data.phone_number
            request.session['issue_date'] = validated_data.issue_date
            request.session['return_date'] = validated_data.return_date
            # ---------------- SEND DATA TO HOME.HTML ----------------

            context['success'] = True
            context['name'] = validated_data.name
            context['email'] = validated_data.email
            context['phone_number'] = validated_data.phone_number
            context['issue_date'] = validated_data.issue_date
            context['return_date'] = validated_data.return_date
            context['file_name'] = uploaded_file.name
            # CSV DATA TABLE
            context['table'] = df.to_html(classes='table table-dark table-striped table-bordered',index=True)
            # DESCRIBE TABLE
            context['describe'] = df.describe().to_html(classes='table table-dark table-striped table-bordered',index=True)
        except Exception as e:

            context['error'] = f'Error reading CSV file: {e}'
        # AJAX will receive this complete rendered home.html
        return render(request, 'home.html', context)
    # ---------------- GET REQUEST ----------------
    elif request.method == 'GET':
        file_name = request.session.get('csv_file')
        if file_name:
            file_path = os.path.join(settings.MEDIA_ROOT,file_name)
            try:
                df: pd.DataFrame = pd.read_csv(file_path)
                # Get previous data from session
                context['success'] = True
                context['name'] = request.session.get('name')
                context['email'] = request.session.get('email')
                context['phone_number'] = request.session.get('phone_number')
                context['issue_date'] = request.session.get('issue_date')
                context['return_date'] = request.session.get('return_date')
                context['file_name'] = file_name
                context['table'] = df.to_html(classes='table table-dark table-striped table-bordered',index=True)
                context['describe'] = df.describe().to_html(classes='table table-dark table-striped table-bordered',index=True)
            except Exception as e:
                context['error'] = f'Error reading CSV file: {e}'
    return render(request, 'home.html', context)

def search_page(request:HttpRequest)->HttpResponse:
    return render(request,'search.html')

def search_file(request:HttpRequest):
    if request.method != 'POST':
        return JsonResponse({'status':False,'message':'Only POST request is allowed.'})
    search_column = request.POST.get('search_column')
    search_value = request.POST.get('search_value')
    if not search_column:
        return JsonResponse({'status':False,'message': 'Please select correct column for search.'})
    if not search_value:
        return JsonResponse({'status':False,'message': 'Please select correct value for above column.'})
    # Get the file name
    file_name = request.session.get('csv_file')
    if not file_name:
        return JsonResponse({'status':False,'message':'Please Upload a CSV file first.'})
    file_path = os.path.join(settings.MEDIA_ROOT,file_name)
    try:
        df:pd.DataFrame = pd.read_csv(file_path)
        if search_column not in df.columns:
            return JsonResponse({'status':False,'message':f'Column "{search_column}" does not exists.'})
        result = df.loc[df[search_column].astype(str).str.contains(search_value,case=False,na=False)]

        if result.empty:
            return JsonResponse({'status':False,'message':'No matching data found.'})
        # Convert the result to HTML
        table = result.to_html(classes='table table-dark table-striped',index=True)
        return JsonResponse({'status':True,'message': f'{len(result)} result(s) found.','table':table})
    except Exception as e:
        return JsonResponse({'status':False,'message':f'Error searching file: {e}'})