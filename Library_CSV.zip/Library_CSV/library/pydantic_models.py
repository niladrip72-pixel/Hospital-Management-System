from pydantic import BaseModel,Field

class LibraryData(BaseModel):
    name:str = Field(...,min_length=3,
                     max_length=100,
                     pattern=r'[a-zA-Z ]+',
                     description='User Name',
                     examples='Jhon')
    email:str = Field(...,
                      description='User Email',
                      examples='abcd123@gmail.com')
    phone_number:str = Field(...,
                             pattern=r'[6-9][0-9]{9}',
                             description='User Phone Number',
                             examples='9836716592')
    issue_date:str
    return_date:str