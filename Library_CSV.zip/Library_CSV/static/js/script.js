$(document).ready(function(){
    console.log('We are using jQuery for CSV handling.');

    $("#uploadForm").submit(function(event){
        event.preventDefault();
        console.log('Form is Uploaded and we are access the Form By Form ID.');

        let formData = new FormData(this);

        $.ajax({
            url : `/upload_file/`,
            method : 'POST',
            data : formData,
            processData : false,
            contentType : false,
            headers : {'X-CSRFToken' : $('input[name=csrfmiddlewaretoken]').val()},

            success:function(response){
                console.log('CSV file uploaded successfully !');
                window.location.href = '/upload_file/';
            },

            error:function(err){
                console.log(err.responseText);
                $("#uploadMessage").html('<p style="color:red;">'+'Something went wrong while uploading.'+'</p>');
            }
        });
    });

    $('#searchForm').submit(function(event){
        event.preventDefault();

        let searchColumn = $("#search_column").val();
        let searchValue = $("#search_value").val();

        $.ajax({
            url : `/search_file/`,
            method : 'POST',
            data : {
                search_column : searchColumn,
                search_value : searchValue,
                csrfmiddlewaretoken : $('input[name=csrfmiddlewaretoken]').val()
            },

            success:function(response){
                if (response.status){
                    $("#searchMessage").html('<p style="color:green;">'+response.message+'</p>');
                    $("#searchResult").html(response.table);
                }
                else{
                    $("#searchMessage").html('<p style="color:red;">'+ response.message + '</p>');
                    $("#searchResult").html("");
                }
            },
            error:function(err){
                console.log(err.responseText);
                $("#searchMessage").html('<p style="color:red;">' + 'Something went wrong while searching.' + '</p>');
            }
        });
    });
});