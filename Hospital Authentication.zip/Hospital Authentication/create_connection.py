import psycopg2
import logging

logging.basicConfig(
    filename='hospital.log',
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
class Database:
    def __init__(self):
        self.host='localhost'
        self.database='hospital_db'
        self.user='client'
        self.password='client123'
        self.conn=None
        self.cursor=None
    def __enter__(self):
        self.conn=psycopg2.connect(
            host=self.host,
            database=self.database,
            user=self.user,
            password=self.password
        )
        self.cursor=self.conn.cursor()
        return self
    def __exit__(self, exc_type,exc_value,tb):
        if exc_type:
            self.conn.rollback()
        else:
            self.conn.commit()
            self.cursor.close()
            self.conn.close()
    
    