# Hospital Authentication
# Three Tables are required- 1. Doctor , 2. Patient , 3. Report
# The id of the doctor is the foreign key of Patient table and the key of the patient_id is the foreign key of report.
# Joining the tables using the postgres and importing the model psycopg2
# Using- Decorator, Logging, Regular Expression ,Exception Handling and context Manager and also using OOPs concept

from create_connection import Database
from create_table import TableCreation
from doctors_table_creation import Doctor
from patient_table_creation import Patient
from report_table_creation import Report
from join_all_tables import JoinTables
import logging

def main():
    tableRef:TableCreation=TableCreation()
    doctorRef:Doctor=Doctor()
    patientRef:Patient=Patient()
    reportRef:Report=Report()
    joinRef:JoinTables=JoinTables()
#-----We have to first create the tables----->
    tableRef.create_table_doctors()
    tableRef.create_table_patient()
    tableRef.create_table_report()
    while True:
        print("--------MAIN MENU-----------")
        print("1. Doctors Table Operation.")
        print("2. Patient Table Operation.")
        print("3. Report Table Operation.")
        print("4. Joining All The Tables.")
        print("5. Exit The Program.")
        try:
            choice:int=int(input("\nEnter your choice = "))
            if choice==1:
#---------------------DOCTORS MENU-------------------------------------
                while True:
                    print("\n-------DOCTOR MENU--------\n")
                    print("1. Add Doctor Details.")
                    print("2. Display All Available Doctors.")
                    print("3. Search Doctor.")
                    print("4. Update Doctor's Details.")
                    print("5. Delete The Doctor.")
                    print("6. End Doctor Operation")
                    try:
                        doctor_choice:int=int(input("\nEnter your choice = "))
                        if doctor_choice==1:
                            doctorRef.input_doctors()
                        elif doctor_choice==2:
                            doctorRef.display_doctors()
                        elif doctor_choice==3:
                            doctorRef.search_doctors()
                        elif doctor_choice==4:
                            doctorRef.update_doctors()
                        elif doctor_choice==5:
                            doctorRef.delete_doctors()
                        elif doctor_choice==6:
                            print("All Operation Is Done , Now Exit From Doctor Operation.")
                            break
                        else:
                            logging.warning("You took a wrong Guess")
                            print("You take a wrong guess.")
                    except ValueError:
                        logging.error("Please Put the correct choice.")
                    except Exception as e:
                        logging.error(str(e))
                        print('Error : ',e)
            elif choice==2:
#-------------------PATIENT MENU--------------------------------------
                while True:
                    print("\n-----------PATIENT MENU-----------")
                    print("1. Add Patient details.")
                    print("2. Display Patient.")
                    print("3. Search Patient.")
                    print("4. Update Patient.")
                    print("5. Delete Patient.")
                    print("6. End Patient Operation.")
                    try:
                        patient_choice:int=int(input("Enter your choice = "))
                        if patient_choice==1:
                            patientRef.inputPatient()
                        elif patient_choice==2:
                            patientRef.displayPatient()
                        elif patient_choice==3:
                            patientRef.searchPatients()
                        elif patient_choice==4:
                            patientRef.updatePatient()
                        elif patient_choice==5:
                            patientRef.deletePatient()
                        elif patient_choice==6:
                            print("All Operation is Done , now exit from the patient operation.")
                            break
                        else:
                            logging.warning("You took a wrong guess.")
                            print("Please take a correct guess")
                    except ValueError:
                        logging.error("You Give the wrong choice.")
                    except Exception as e:
                        logging.error(str(e))
                        print("Error : ",e)
            elif choice==3:
#-----------------------REPORT MENU--------------------------------------
                while True:
                    print("\n---------REPORT MENU----------")
                    print("1. Add Report Input.")
                    print("2. Display Report.")
                    print("3. Search Report.")
                    print("4. Update Report.")
                    print("5. Delete Report.")
                    print("6. End Report Operation.")
                    try:
                        report_choice:int=int(input("Enter your choice = "))
                        if report_choice==1:
                            reportRef.reportInput()
                        elif report_choice==2:
                            reportRef.displayReport()
                        elif report_choice==3:
                            reportRef.searchReport()
                        elif report_choice==4:
                            reportRef.updateReport()
                        elif report_choice==5:
                            reportRef.deleteReport()
                        elif report_choice==6:
                            print("All Operation is done, now exit from report operation.")
                            break
                        else:
                            logging.warning("You took a wrong guess.")
                            print("Please take a correct guess")
                    except ValueError:
                        logging.error("You Give the wrong choice.")
                    except Exception as e:
                        logging.error(str(e))
                        print("Error : ",e)
            elif choice==4:
#------------------------JOINNING MENU-------------------------------
                while True:
                    print("\n---------JOINING TABLE MENU----------")
                    print("1. Doctor + Patient Join.")
                    print("2. Patient + Report Join.")
                    print("3. Patient + Doctor + Patient Join.")
                    print("4. Doctor -> Patient Count.")
                    print("5. Patient -> Report Count.")
                    print("6. End Joinning Operation.")
                    try:
                        join_choice:int=int(input("Enter Your Choice = "))
                        if join_choice==1:
                            joinRef.doctor_patient_join()
                        elif join_choice==2:
                            joinRef.patient_report_join()
                        elif join_choice==3:
                            joinRef.patient_doctor_report()
                        elif join_choice==4:
                            joinRef.doctors_patient_count()
                        elif join_choice==5:
                            joinRef.patient_report_count()
                        elif join_choice==6:
                            print("All Operation is done. Now exit from the joining part.")
                            break
                        else:
                            logging.warning("You took a wrong guess.")
                            print("Please take a correct guess")
                    except ValueError:
                        logging.error("You Give the wrong choice.")
                    except Exception as e:
                        logging.error(str(e))
                        print("Error : ",e)
            elif choice==5:
                print("The program teminates here. Thank You for choosing our Hospital.")
                break
            else:
                print("Try Again.....| Your Attempt is Faill.")
        except ValueError:
            logging.error("You give the wrong choice.")
            print("You take a wrong choice , Try again...")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
if __name__=='__main__':
    main()