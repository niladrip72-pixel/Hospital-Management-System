from create_connection import Database
from create_table import TableCreation
import re,logging
import psycopg2
def logger(func:object):
        def wrapper(*args,**kwargs):
            logging.info(f"{func.__name__} started.")
            result=func(*args,**kwargs)
            logging.info(f"{func.__name__} Finished !")
            return result
        return wrapper

class Doctor:
    def __init__(self):
        pass
#------------Doctors Details Add-------------------
    @logger
    def input_doctors(self):
        try:
            with Database() as db:
                d_name:str=input("Enter the name of the doctor = ")
                d_email:str=input("Enter the email address of the doctor = ")
                d_special:str=input("Enter the specialisation of the doctor = ")
                d_available:str=input("Enter the avialable day beside ('Sun'/'Sat') of the doctor = ")
                d_degrees:str=input("Enter the degree of the doctor = ")
                if not re.fullmatch(r'[a-zA-Z ]+',d_name):
                    print("The name not in the correct format.")
                    logging.error("The name should be in the correct format.")
                    return
                print("The name in the format.")
                if not re.fullmatch(r'[a-zA-Z]+\d*@[a-zA-Z]+\.[a-zA-Z]+',d_email):
                    print("The email is wrong.")
                    logging.error("The email not in the format.")
                    return
                print("\nThe email in the correct format you may proceed now.")
                if d_available not in ('Mon','Tue','Wed','Thurs','Fri'):
                    print("Doctors not available.")
                    logging.warning("Doctors are not available beside those days.")
                db.cursor.execute(
                    """insert into doctors (doc_name,doc_email,specialisation,available_day,degrees) 
                    values (%s,%s,%s,%s,%s)""",
                    (d_name,d_email,d_special,d_available,d_degrees))
                db.conn.commit()
                logging.info(f"Doctor : {d_name}'s data added successfully !")
                print("Doctor's details added successfully !")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
        except psycopg2.IntegrityError:
            logging.warning("The email of the doctor should be unique.")
            print("Duplicate email can not be issued.")
#-----------------Display Doctors-----------------
    @logger
    def display_doctors(self):
        try:
            with Database() as db:
                db.cursor.execute("select * from doctors;")
                users=db.cursor.fetchall()
                if not users:
                    print("No users found.")
                    logging.info("Users not available.")
                    return
                print("-"*100)
                print(
                    f"{'Doc_ID':<5}"
                    f"{'Doc_name':<20}"
                    f"{'Doc_email':<25}"
                    f"{'Doc_special':<28}"
                    f"{'Doc_availability':<12}"
                    f"{'Doc_degree':<15}"
                )        
                print("-"*100)
                for user in users:
                    print(f'{user[0]:<5}'
                          f'{user[1]:<20}'
                          f'{user[2]:<25}'
                          f'{user[3]:<28}'
                          f'{user[4]:<12}'
                          f'{user[5]:<15}')
                logging.info("All doctors details shown successfully !")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
#---------------Search Doctors---------------
    @logger 
    def search_doctors(self):
        try:
            d_id:str=input("Enter the ID of the doctor you want to search = ")
            with Database() as db:
                db.cursor.execute('select * from doctors where doc_id=%s;',(d_id,))
                data=db.cursor.fetchone()
                if not data:
                    print(f"{d_id} : You ask for wrong Doctor ID.")
                    logging.warning(f" You give the wrong ID : {d_id}")
                    return
                print("--------Doctor Details--------")
                print(f"Doctor ID : {data[0]}"
                      f"Doctor Name : {data[1]}"
                      f"Doctor Email : {data[2]}"
                      f"Doctor Available : {data[4]}")
        except ValueError:
            logging.warning("Please give the correct Doctor ID.")
            print("Put the correct ID of the doctor.")
        except Exception as e:
            logging.error(str(e))
            print("Error : ", e)
#---------------Update Doctors Details----------------
    @logger
    def update_doctors(self):
        try:
            d_id:int=int(input("Enter the ID of the doctor you want to search = "))
            with Database() as db:
                db.cursor.execute('select * from doctors where doc_id=%s',(d_id,))
                if not db.cursor.fetchone():
                    print("The updation is not possible.")
                    return
                d_name:str=input("Enter the new Doctor's name = ")
                d_email:str=input("Enter the email address = ")
                d_available:str=input("Enter the available day = ")
                d_specialisation:str=input("Enter the new doctors specialisation = ")
                d_degree:str=input("Enter the degree of the doctor = ")
                while True:
                    print("------MENU-------")
                    print("1. New Doctor Name.")
                    print("2. New Doctor's Email.")
                    print("3. Specialisation.")
                    print("4. Available day.")
                    print("5. Doctor's degree.")
                    print("6. No updation is needed.")
                    try:
                        choice:int=int(input("Enter your choice = "))
                        if choice==1:
                            db.cursor.execute('update doctors set doc_name=%s where doc_id=%s;',(d_name,d_id))
                            db.conn.commit()
                            print("Username updated successfully ! ")
                        elif choice==2:
                            db.cursor.execute('update doctors set doc_email=%s where doc_id=%s;',(d_email,d_id))
                            db.conn.commit()
                            print("Email updated successfully !")
                        elif choice==3:
                            db.cursor.execute('update doctors set specialisation=%s where doc_id=%s;',(d_specialisation,d_id))
                            db.conn.commit()
                        elif choice==4:
                            db.cursor.execute('update doctors set available_day=%s where doc_id=%s;',(d_available,d_id))
                            db.conn.commit()
                        elif choice==5:
                            db.cursor.execute('update doctors set degrees=%s where doc_id=%s;',(d_degree,d_id))
                            db.conn.commit()
                        elif choice==6:
                            print("All updation is completed otherwise no updation is needed.")
                            break
                        logging.error("You take the wrong choice.")
                    except ValueError:
                        logging.warning("You have the wrong choice .")
                        print("Wrong choice would not be submitted.")
        except ValueError:
            logging.warning("You give the wrong doctor ID.")
            print("Wrong Doctor Id will not be submitted.")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
        except psycopg2.IntegrityError:
            logging.warning("Duplicate email is not allowed.")
            print("Email should be unique.")
#---------------Delete Doctors----------------------
    @logger
    def delete_doctors(self):
        try:
            d_id:int=int(input("Enter the Doctor ID you want to delete = "))
            with Database() as db:
                db.cursor.execute('select * from doctors where doc_id = %s;',(d_id,))
                if not db.cursor.fetchone():
                    print("Nothing to delete.")
                    return
                db.cursor.execute('delete from doctors where doc_id=%s;',(d_id,))
                db.conn.commit()
                print("The doctor details deleted successfully !")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)