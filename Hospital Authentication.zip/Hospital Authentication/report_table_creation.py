from create_connection import Database
from create_table import TableCreation
import logging,psycopg2

def loggerReport(func:object):
    def wrapper(*args,**kwargs):
        logging.info(f"{func.__name__} started.")
        result=func(*args,**kwargs)
        logging.info(f"{func.__name__} Finished !")
        return result
    return wrapper
class Report:
    def __init__(self):
        pass
#---------Report details upload---------
    @loggerReport
    def reportInput(self):
        try:
            with Database()as db:
                summary:str=input("Enter full report of the patient = ")
                r_id:int=int(input("Enter the report ID which is related to the patient table = "))
                '''insert into report (report_summary,patient_id) values (%s,%s);'''
                db.cursor.execute('''insert into report (report_summary,patient_id) 
                                  values (%s,%s);''',(summary,r_id))
                db.conn.commit()
                logging.info("Report uploaded successfully !")
                print("Patient Medical report Uploaded successfully !")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
#----------Report display--------------
    @loggerReport
    def displayReport(self):
        with Database() as db:
            db.cursor.execute('select * from report;')
            record=db.cursor.fetchall()
            if not record:
                print("Patient has no report.")
                logging.info("Patient report card is not created .")
                return
            print("-"*65)
            print(f"{'Report-ID':<10}"
                  f"{'Disease':<20}"
                  f"{'Report-Time':<15}"
                  f"{'Patient-Report-ID':<10}")
            for r in record:
                print(f'{r[0]:<10}'
                      f'{r[1]:<20}'
                      f'{r[2]:<15}'
                      f'{r[3]:<10}')
            logging.info("Patient's report displayed successfully !")
            print("Report display is successfull !")
#------------Report search---------------
    @loggerReport
    def searchReport(self):
        try:
            r_id:int=int(input("Enter the report ID you want to search = "))
            with Database() as db:
                db.cursor.execute('select * from report where report_id=%s;',(r_id,))
                data=db.cursor.fetchone()
                if not data:
                    print(f"{r_id} : The report ID is wrong.")
                    logging.warning(f"Put the Wrong report ID number.")
                    return
                print("\n------REPORT--------")
                print(f"Report-Id :{data[0]}"
                        f"Report-Summary : {data[1]}"
                        f"Report-Time : {data[2]}"
                        f"Patient-ID : {data[3]}")
        except ValueError:
            logging.warning("You give the wrong report ID.")
            print("Give the correct report ID please.")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
#---------------Report Update--------------
    @loggerReport
    def updateReport(self):
        try:
            r_id:int=int(input("Enter the report ID you want to search = "))
            with Database() as db:
                db.cursor.execute('select * from report where report_id=%s;',(r_id,))
                data=db.cursor.fetchone()
                if not data:
                    print(f"{r_id} : The report ID is wrong.")
                    logging.warning(f"Put the Wrong report ID number.")
                    return
                new_id:int=int(input("Enter the new report Id = "))
                new_summary:str=input("Enter the new diseace if it has = ")
                print("1. New ID Update.")
                print("2. New disease update. ")
                try:
                    choice:str=input("Enter your choice = ")
                    while True:
                        if choice=="1":
                            db.cursor.execute('update report set report_id=%s where report_id=%s;',(new_id,r_id))
                            print('Id updated successfully.')
                            db.conn.commit()
                        elif choice=="2":
                            db.cursor.execute('update report set report_summary=%s where report_id=%s;',(new_id,new_summary))
                            db.conn.commit()
                            break
                    print("Updation is completed.")
                except ValueError:
                    print("You take a wrong choice. Please enter a valid choice.")
        except ValueError:
            logging.warning("You give the wrong Report ID.")
            print("Wrong Report ID will not be allowed.")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
#------------Delete Report--------------
    @loggerReport
    def deleteReport(self):
        try:
            r_id:int=int(input("Enter the report ID you want to search = "))
            with Database() as db:
                db.cursor.execute('select * from report where report_id=%s;',(r_id,))
                data=db.cursor.fetchone()
                if not data:
                    print(f"{r_id} : The report ID is wrong.")
                    logging.warning(f"Put the Wrong report ID number.")
                    return
                db.cursor.execute('delete from report where report_id=%s;',(r_id,))
                db.conn.commit()
                print("The report deleted successfully !")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
            
        