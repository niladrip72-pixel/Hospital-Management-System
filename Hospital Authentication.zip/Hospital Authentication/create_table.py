from create_connection import Database
import psycopg2
class TableCreation:
    def __init__(self):
        pass
    def create_table_doctors(self):
        with Database() as db:
            db.cursor.execute('''
            create table if not exists doctors (
            doc_id serial primary key,
            doc_name varchar(200) not null,
            doc_email varchar(250) unique not null,
            specialisation varchar(90) not null,
            available_day varchar(30) check (available_day in ('Mon','Tue','Wed','Thurs','Fri')) not null,
            degrees varchar(50) not null);
            ''')
            db.conn.commit()
    def create_table_patient(self):
        with Database() as db:
            db.cursor.execute(
            """
            create table if not exists patient (
            p_id serial primary key,
            p_name varchar(200) not null,
            p_phone varchar(20) unique not null,
            p_address varchar(200) not null,
            p_doc_id integer,
            constraint fk_doctor foreign key(p_doc_id)
            references doctors (doc_id)
            on delete cascade
            );
            """
            )
            db.conn.commit()
    def create_table_report(self):
        with Database() as db:
            '''create table if not exists report (
            report_id serial primary key,
            report_summary text,
            report_generate_time timestamp default current_timestamp,
            patient_id integer,
            constraint fk_report foreign key(patient_id)
            references patient(p_id)
            on delete cascade);'''
            db.conn.commit()