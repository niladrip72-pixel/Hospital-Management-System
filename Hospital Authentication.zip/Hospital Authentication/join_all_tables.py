from create_connection import Database
from create_table import TableCreation
from doctors_table_creation import Doctor
from report_table_creation import Report
from patient_table_creation import Patient
import logging,psycopg2
def loggerJoin(func:object):
    def wrapper(*args,**kwargs):
        print(f"{func.__name__} Started.")
        result=func(*args,**kwargs)
        print(f"{func.__name__} Finished !")
        return result
    return wrapper
class JoinTables:
    def __init__(self):
        pass
#-----------To See doctors with their patient Name, address and phone NUmber--------------
    @loggerJoin
    def doctor_patient_join(self):
        try:
            with Database() as db:
                querry='''select d.doc_name,d.specialisation,p.p_name,p.p_phone,p.p_address from doctors d 
                join patient p on d.doc_id=p.p_doc_id order by d.doc_id;'''
                db.cursor.execute(querry)
                records=db.cursor.fetchall()
                if not records:
                    print("No Data found.")
                    return
                print("-"*100)
                print(f"{'Doctor Name':<20}"
                      f"{'Specialisation':<15}"
                      f"{'Patient Name':<20}"
                      f"{'Patient Phone Number':<12}"
                      f"{'Patient Address':<25}")
                print("-"*100)
                for r in records:
                    print(f"{r[0]:<20}"
                          f"{r[1]:<15}"
                          f"{r[2]:<20}"
                          f"{r[3]:<12}"
                          f"{r[4]:<25}")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
#-----------Patient With Report------------
    @loggerJoin
    def patient_report_join(self):
        try:
            with Database() as db:
                querry='''select p.p_name,p.p_address,r.report_summary,r.report_generate_time from
                patient p join report r on p.p_id = r.patient_id;'''
                db.cursor.execute(querry)
                records=db.cursor.fetchall()
                if not records:
                    print("No data found.")
                    return
                print("-"*100)
                print(f"{'Patient Name':<20}"
                      f"{'Patient Address':<25}"
                      f"{'Report Summary':<25}"
                      f"{'Report Time':<15}")
                print("-"*100)
                for r in records:
                    print(f"{r[0]:<20}"
                          f"{r[1]:<25}"
                          f"{r[2]:<25}"
                          f"{r[3]:<15}")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
#-----------Patient+Report+Doctor----------------
    @loggerJoin
    def patient_doctor_report(self):
        try:
            with Database() as db:
                querry='''
                select d.doc_name,d.specialisation,p.p_name,p.p_phone,p.p_address,r.r_summary,r.report_generate_time 
                from doctors d join patient p on d.doc_id=p.p_doc_id
                join report r on p.p_id = r.patient_id'''
                db.cursor.execute(querry)
                records=db.cursor.fetchall()
                if not records:
                    print("No Data Found.")
                    return
                print("-"*130)
                print(
                    f"{'Doctor Name':<20}"
                    f"{'Specialisation':<20}"
                    f"{'Patient Name':<20}"
                    f"{'Phone Number':<15}"
                    f"{'Disease':<25}"
                )
                print("-"*130)
                for row in records:
                    print(
                        f"{row[0]:<20}"
                        f"{row[1]:<20}"
                        f"{row[2]:<20}"
                        f"{row[3]:<15}"
                        f"{row[4]:<25}"
                    )
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
#--------------Doctors wise Patient Count---------------
    @loggerJoin
    def doctors_patient_count(self):
        try:
            with Database() as db:
                querry='''
                select d.doc_name as name, count(p.p_id) as total_patient from doctors d 
                join 
                patient p on d.doc_id = p.p_doc_id 
                group by name order by total_patient desc;'''
                db.cursor.execute(querry)
                records=db.cursor.fetchall()
                if not records:
                    print("No Data Found.")
                    return
                print("-"*80)
                print(f"{'Doctor Name':<20}"
                      f"{'Total Number Of Patient':<10}")
                print("-"*80)
                for r in records:
                    print(f"{r[0]:<20}"
                          f"{r[1]:<10}")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
#---------------Patient wise Report Count--------------
    @loggerJoin
    def patient_report_count(self):
        try:
            with Database() as db:
                querry='''select p.p_name,p.p_phone,p.p_address,count(r.report_id) as number_of_report,r.report_summary from patient p 
                join 
                report r on p.p_id=r.patient_id 
                group by 
                p.p_name,p.p_phone,p.p_address,r.report_summary;'''
                db.cursor.execute(querry)
                records=db.cursor.fetchall()
                if not records:
                    print("No Data Found.")
                    return
                print("-"*140)
                print(f"{'Patient Name':<20}"
                      f"{'Patient Phone Number':<12}"
                      f"{'Patient Address':<25}"
                      f"{'Number Of Report':<8}"
                      f"{'Report Summary':<25}")
                print("-"*140)
                for r in records:
                    print(f"{r[0]:<20}"
                          f"{r[1]:<12}"
                          f"{r[2]:<25}"
                          f"{r[3]:<8}"
                          f"{r[4]:<25}")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)