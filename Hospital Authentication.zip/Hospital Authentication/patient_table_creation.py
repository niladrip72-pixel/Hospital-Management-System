from create_connection import Database
from create_table import TableCreation
from doctors_table_creation import Doctor
import re,logging
import psycopg2
def loggerPatient(func:object):
    def wrapper(*args,**kwargs):
        logging.info(f"{func.__name__} started.")
        result=func(*args,**kwargs)
        logging.info(f"{func.__name__} Finished.")
        return result
    return wrapper
class Patient:
    def __init__(self):
        pass
#----------Patient's Details Add----------
    @loggerPatient
    def inputPatient(self):
        try:
            with Database() as db:
                name:str=input("Enter the name of the patient = ")
                phone:str=input('Enter the phone number of the patient = ')
                address:str=input("Enter the address of the patient = ")
                patient_id:int=int(input("Enter the patient ID which one is related to the doctors table = "))
                if not re.fullmatch(r'[a-zA-Z ]+',name):
                    print("The name not in the correct format.")
                    logging.error("The name should be in the correct format.")
                    return
                print("The name is correct !")
                if not re.fullmatch(r'^[6-9][0-9]{9}$',phone):
                    print("The phone number is wrong.")
                    logging.error("The phone number not in the format.")
                    return
                print("The phone number is in the format.")
                db.cursor.execute('''
                insert into patient (p_name,p_phone,p_address,p_doc_id)
                values (%s,%s,%s,%s);
                ''',(name,phone,address,patient_id))
                db.conn.commit()
                logging.info(f"{name}'s details added successfully !")
                print("Patient details added . ")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
        except psycopg2.IntegrityError:
            logging.warning("Phone number of the patient should be unique.")
            print("Duplicate phone number is not allowed.")
#------------Display the Patient---------------
    @loggerPatient
    def displayPatient(self):
        try:
            with Database() as db:
                db.cursor.execute('select * from patient;')
                records=db.cursor.fetchall()
                if not records:
                    print("No patient is founded.")
                    logging.info("Patient should not include yet !")
                    return
                print("-"*80)
                print(f"{'Patient_ID':<10}"
                      f"{'Patient_name':<20}"
                      f"{'Patient_phone_number':<12}"
                      f"{'Patient_address':<30}"
                      f"{'Patient_Doc_ID':<8}")
                print("-"*80)
                for rec in records:
                    print(f'{rec[0]:<10}'
                          f'{rec[1]:<20}'
                          f'{rec[2]:12}'
                          f'{rec[3]:<30}'
                          f'{rec[4]:<8}')
                logging.info("All Patients details shown successfully !")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
#-----------------Search Patients----------------
    @loggerPatient
    def searchPatients(self):
        try:
            p_id:int=int(input("Enter the ID of the patient you want to see = "))
            with Database() as db:
                db.cursor.execute('select * from patient where p_id=%s;',(p_id,))
                data=db.cursor.fetchone()
                if not data:
                    print(f"{p_id} : You ask for wrong Patient ID.")
                    logging.warning(f" You give the wrong ID : {p_id}")
                    return  
                print("--------Patient Details-----------")
                print(f"Patient ID :{data[0]}"
                        f"Patient Name : {data[1]}"
                        f"Patient PhoneNumber : {data[2]}"
                        f"Patient Address : {data[3]}"
                        f"Patient's Doctor ID : {data[4]}")
        except ValueError:
            logging.warning("Please give the correct Patient ID.")
            print("Put the correct ID of the patient.")
        except Exception as e:
            logging.error(str(e))
            print("Error : ", e)
#---------------Update Patient---------------------
    @loggerPatient
    def updatePatient(self):
        try:
            p_id:int=int(input("Enter the ID of the patient you want to see = "))
            with Database() as db:
                db.cursor.execute('select * from patient where p_id=%s;',(p_id,))
                data=db.cursor.fetchone()
                if not data:
                    print(f"{p_id} : You ask for wrong Patient ID.")
                    logging.warning(f" You give the wrong ID : {p_id}")
                    return  
                name:str=input("Enter the new name of the patient = ") 
                phone:str=input("Enter the new phone number of the patient = ")
                address:str=input("Enter the new address of the patient = ")
                patient_new_id:int=int(input("Enter the new ID of the Doctor's Patient = "))
                while True:
                    print("-------MENU---------")
                    print("1. New Patient name.")
                    print("2. New Phone number")
                    print("3. New Address.")
                    print("4. New patient Doctor ID = ") 
                    print("5. No updation is needed.")
                    try:
                        choice:int=int(input("Enter your choice = "))
                        if choice==1:
                            db.cursor.execute('update patient set p_name=%s where p_id=%s;',(name,p_id))
                            db.conn.commit()
                            print("Patient name updated successfully !")
                        elif choice==2:
                            db.cursor.execute('update patient set p_phone=%s where p_id=%s;',(phone,p_id))
                            db.conn.commit()
                            print("Patient's phone number updated successfully !")
                        elif choice==3:
                            db.cursor.execute('update patient set p_address=%s where p_id=%s;',(address,p_id))
                            db.conn.commit()
                            print("New address updated successfully !")
                        elif choice==4:
                            db.cursor.execute('update patient set p_doc_id=%s where p_id=%s;',(patient_new_id,p_id)) 
                            db.conn.commit()
                            print("New ID Updated.")
                        elif choice==5:
                            print("All updation is completed otherwise no updation is needed.")
                            break
                        logging.error("You take the wrong choice.")
                    except ValueError:
                        logging.warning("You have the wrong choice .")
                        print("Wrong choice would not be submitted.")
        except ValueError:
            logging.warning("You give the wrong Patient ID.")
            print("Wrong Patient Id will not be submitted.")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)
        except psycopg2.IntegrityError:
            logging.warning("Duplicate Phone Number is not allowed.")
            print("Phone number should be unique.") 
#------------Delete Patient--------------
    @loggerPatient
    def deletePatient(self):
        try:
            p_id:int=int(input("Enter the Patient ID you want to delete = "))
            with Database() as db:
                db.cursor.execute('select * from patient where p_id = %s;',(p_id,))
                if not db.cursor.fetchone():
                    print("Nothing to delete.")
                    return
                db.cursor.execute('delete from patient where p_id=%s;',(p_id,))
                db.conn.commit()
                print("The Patient details deleted successfully !")
        except Exception as e:
            logging.error(str(e))
            print("Error : ",e)