#from django.contrib import admin
from django.urls import path
from .views import *
urlpatterns = [
    path('',student_list,name='student_list'),
    path('add/',add_students,name='add_students'),
    path('update/<int:id>/',update_students,name='update_students'),
    path('delete/<int:id>',delete_students,name='delete_students'),
    #path('admin/', admin.site.urls),
]
