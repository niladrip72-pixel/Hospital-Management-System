from django.shortcuts import render,get_object_or_404
from django.http import HttpRequest,HttpResponse,JsonResponse
from django.db.models import QuerySet
from django.template.loader import render_to_string
from .models import Student

def student_list(request:HttpRequest)->HttpResponse:
    students:QuerySet=Student.objects.all()
    return render(request,'studentApp/add_students.html',{"students" : students})
def add_students(request:HttpRequest):
    if request.method == 'POST':  # Here the 'POST' is the AJAX post , so the AJAX send the request
        #  Here we are taking the values from the templates
        student_name :str = request.POST['student_name']
        subject_name :str = request.POST['subject_name']
        marks = request.POST['marks']
        feedback = request.POST['feedback']
        # Validation
        if student_name:
            if not Student.objects.filter(name=student_name).exists():   # Filter is a very specific method and it also act like an adapter and here 'name' is the attribute of the database so, the filter method checks the query 'select * from students where name='student_name(anyname)';
                Student.objects.create(name=student_name,subject_name=subject_name,marks=marks,feedback = feedback)  # If not exists then create those attribute and adding those values from the template
                students:QuerySet=Student.objects.all()                  # It just take the query not retrive the data , so ORM basically give us the fasility to not write the raw query , instead we are using ORM to collect data
                html_string = render_to_string('partial/student_rows.html',{'students' : students})   # We are changing the data into a string format, python doesn't understand any raw queryset
                return JsonResponse({'students' : html_string, 'message' : 'Students details added successsfully .'}, status=201)  #In this line we are sending the string into ajax in the form of jsonresponse because ajax only understand jesonresponse
            else :
                return JsonResponse({'message' : 'Student detail already exists.'},status=400)
        else :
            return JsonResponse({'success' : True, 'message' : 'Student name should be provided.'},status=400)
    else :
        return render(request,'studentApp/add_students.html')
def update_students(request:HttpRequest,id:int):
    if request.method == 'POST' :
        student_name = request.POST['student_name']
        subject_name = request.POST['subject_name']
        marks = request.POST['marks']
        feedback = request.POST['feedback']

        if not Student.objects.filter(name=student_name).exclude(id=id).exists():    # exclude is used for prevent duplicate values. If the id is already exists then exclude it
            student = Student.objects.get(id=id)
            student.name = student_name    # Here the 'student.name' storing the value of the perticular database and our main moto is to update the values.
            student.subject_name = subject_name
            student.marks = marks
            student.feedback = feedback
            student.save()
            students : QuerySet = Student.objects.all()
            html_string = render_to_string('partial/student_rows.html',{'students' : students})
            return JsonResponse({'students' : html_string , 'message' : 'Student details updated successfully !'}, status = 201)
def delete_students(request,id):
    if request.method == 'POST':
        student = get_object_or_404(Student,pk=id)
        student.delete()
        students = Student.objects.all()
        html_string = render_to_string('partial/student_rows.html',{'students' : students})
        return JsonResponse({'students' :html_string , 'message' : 'Student delete successfull !'})