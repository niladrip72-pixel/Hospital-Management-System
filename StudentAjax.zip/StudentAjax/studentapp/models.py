from django.db import models

class Student(models.Model):
    name=models.CharField(max_length=100)
    subject_name=models.CharField(max_length=100)
    marks=models.IntegerField()
    feedback=models.TextField()

    def __str__(self):
        return self.name