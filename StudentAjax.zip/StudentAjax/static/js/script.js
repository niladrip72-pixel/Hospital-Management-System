$(document).ready(function(){
    console.log('We are using the jQuery.');

    $('#btnRegister').click(function(event){
        event.preventDefault();
        console.log('Button clicked.');
        const student_id = $('#student_id').val();
        const student_name = $('#student_name').val();
        const subject_name = $('#subject_name').val();
        const marks = $('#marks').val();
        const feedback = $('#feedback').val();
        const csrfmiddlewaretoken = $('input[name=csrfmiddlewaretoken]').val();
        
        $.ajax({
            url : student_id ? `/students/update/${student_id}/` : `/students/add/`,
            method : 'POST',
            data : {
                student_id : student_id,
                student_name : student_name,
                subject_name : subject_name,
                marks : marks,
                feedback : feedback,
                csrfmiddlewaretoken : csrfmiddlewaretoken
            },
            success : function(response){
                $('#student_name').val('');
                $('#subject_name').val('');
                $('#marks').val(0);
                $('#feedback').val('');
                $('#btnRegister').text('ADD');

                $('#acknowledge').text(response.message)
                    .css('color','green')
                    .fadeIn().delay(3600).fadeOut();
                $('#studentList').html(response.students)
            },
            error : function(error){
                const errmsg = error.responseJSON?.message || 'An error occured !';
                $('#acknowledge').text(errmsg)
                    .css('color','red')
                    .fadeIn().delay(2500).fadeOut();
            }
        });
    });
    
    $(document).on('click','.edit-btn',function(event){
        event.preventDefault();
        const student_id = $(this).data('id');
        const student_name = $(this).data('name');
        const subject_name = $(this).data('subject_name');
        const marks = $(this).data('marks');
        const feedback = $(this).data('feedback');

        console.log(`Student ID : ${student_id} Student Name : ${student_name} Subject Name : ${subject_name} Marks : ${marks} Feedback : ${feedback}`)

        $('#student_id').val(student_id);
        $('#student_name').val(student_name);
        $('#subject_name').val(subject_name);
        $('#marks').val(marks);
        $('#feedback').val(feedback);
        $('#btnRegister').text('UPDATE');
    });

    $(document).on('click','.delete-btn',function(event){
        event.preventDefault();
        const student_id = $(this).data('id');
        const csrftoken = $('input[name=csrfmiddlewaretoken]').val();
        if(!confirm('Are you sure to delete the student details !'))
            return ;
        
        $.ajax({
            url : `delete/${student_id}`,
            method : 'POST',
            data : {
                csrfmiddlewaretoken : csrftoken
            },
            success : function(response){
                $('#acknowledge').text(response.message)
                    .css('color','green')
                    .fadeIn().delay(3000).fadeOut()
                $('#studentList').html(response.students)
            },
            error : function(response){
                $('#acknowledge').text('Failed to delete Students details.')
                    .css('color','red')
                    .fadeIn().delay(2000).fadeOut()
            }
        });
    });
});