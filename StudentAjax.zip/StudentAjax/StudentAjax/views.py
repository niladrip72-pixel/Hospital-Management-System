from django.http import HttpRequest,HttpResponse
from django.shortcuts import render

def home(request:HttpRequest)->HttpResponse:
    msg='Welcome to the Student Management Page.'
    return render(request,'index.html',{'message' : msg })