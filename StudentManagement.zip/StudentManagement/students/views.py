from django.shortcuts import render,redirect
from django.http import HttpRequest,HttpResponse
import re

input_students:list=[]
pos:int=0

def student_list(request:HttpRequest)->HttpResponse:
    context={
        'students':input_students
    }
    return render(request,'home/student_list.html',context)
#---------Add Student Datas------------

def add_student(request:HttpRequest)->HttpResponse:
    global pos
    context=dict()
    if request.method == 'POST':
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        course=request.POST.get('course')
        name_pattern=r'^[a-zA-Z ]+$'
        email_pattern=r'^[a-zA-Z]+\d*@[a-zA-Z]+\.[a-zA-Z]+$'
        phone_pattern=r'[6-9]\d{9}'
        course_pattern=r'^[a-zA-Z ]+$'
        
        if not name or not email or not phone or not course:
            context['message']='Empty values are not allowed.'
        elif not re.fullmatch(name_pattern,name):
            context['message']='Alphabets and spaces are aloowed for the name of any students.'
        elif not re.fullmatch(email_pattern,email):
            context['message']='Email should be in correct order'
        elif not re.fullmatch(phone_pattern,phone):
            context['message']='Phone number should be 10 digits and also its starts two digits shuld be from 6 to 9'
        elif not re.fullmatch(course_pattern,course):
            context['message']='Alphabets and spaces are alllowed for the course details.'
        else:
            pos += 1
            student_dict:dict={
                'id' : pos,
                'name' : name,
                'email' : email,
                'phone' : phone,
                'course' : course
            }
            input_students.append(student_dict)
            #context['message']='Student details added successfully !'
            context={'students' : input_students}
            return redirect('add_student')
        #context['students']=input_students
    if len(input_students)>0 :
        context = {
            'students' : input_students
        }
    return render(request,'home/student_add.html',context)

#------------Update Student Data----------------

def edit_student(request,student_id):
    student=None
    student_position=None
    for i in range(len(input_students)):
        if input_students[i]['id']==student_id:
            student=input_students[i]
            student_position = i         # Keep updating the student position or the id of the student
            break
    if student is None:
        return HttpResponse('No student record is Found',status=404)
    if request.method == 'POST':
        name= request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        course=request.POST.get('course') 

        #-----Regular Expression Patterns--------

        name_pattern=r'^[a-zA-Z ]+$'
        email_pattern=r'^[a-zA-Z]+\d*@[a-zA-Z]+\.[a-zA-Z]+$'
        phone_pattern=r'[6-9]\d{9}'
        course_pattern=r'^[a-zA-Z ]+$'
        
        #------Validation------------

        if not name or not email or not phone or not course:
            context={
                'student' : student,
                'message' : 'Empty values are not allowed'
            }
            return render(request,'home/student_edit.html',context)
        elif not re.fullmatch(name_pattern,name):
            context={
                'student' : student,
                'message' : 'Alphabets and spaces are allowed for the name'
            }
            return render(request,'home/student_edit.html',context)
        elif not re.fullmatch(email_pattern, email):
            context = {
                'student': student,
                'message': 'Email should be in a correct pattern'
            }
            return render(request,'home/student_edit.html',context)
        elif not re.fullmatch(phone_pattern, phone):
            context = {
                'student': student,
                'message': 'Phone number should be 10 digits and start with 6-9'
            }
            return render(request,'home/student_edit.html',context)
        elif not re.fullmatch(course_pattern, course):
            context = {
                'student': student,
                'message': 'Alphabets and spaces are allowed for the course'
            }
            return render(request,'home/student_edit.html',context)
        else:
            input_students[student_position]['id']=student_id
            input_students[student_position]['name']=name
            input_students[student_position]['email']=email
            input_students[student_position]['phone']=phone
            input_students[student_position]['course']=course
            # context={
            #     'student':input_students[student_position],
            # }
            return redirect('add_student')
    student_dict:dict={
        'student' : student
        }
    return render(request,'home/student_edit.html',student_dict)

#-----------Delete a Student-----------

def delete_student(request,student_id):
    global input_students
    input_students=[student for student in input_students if student['id'] != student_id]
    return redirect('student_list')